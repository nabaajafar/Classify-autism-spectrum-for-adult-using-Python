from tkinter import *
from tkinter import ttk
from PIL import ImageTk, Image
def home():
    root = Toplevel()
    root.title("Autism Detection System-Home Page")
    root.resizable(False, False)
    root.geometry("500x490")
    root.configure(background='#ffffff')


    lbl1 = ttk.Label(root, text="Welcome", background='#ffffff', font="Bold 25",
                         foreground="#AFAF1D")
    lbl1.pack(padx=20, pady=20)
    img = ImageTk.PhotoImage(Image.open("icon3.png"))
    panel = Label(root, image=img)
    panel.pack(pady=20)

    exambtn = Button(root, text="Take Exam", bg='#AFAF1D', fg='#ffffff', font="Bold 15", relief='flat', borderwidth=3)
    exambtn.pack(pady=5)

    resultbtn = Button(root, text="See previous results", bg='#AFAF1D', fg='#ffffff', font="Bold 15", relief='flat', borderwidth=3)
    resultbtn.pack(pady=5)

    logouttbtn = Button(root, text="Logout", bg='#AFAF1D', fg='#ffffff', font="Bold 15", relief='flat',
                       borderwidth=3)
    logouttbtn.pack(pady=5)

    def e():
        root.withdraw()
        e=exam()

    def res():
        root.withdraw()
        r=result()

    def d():
        root.destroy()
        exit()

    exambtn.config(command=e)
    resultbtn.config(command=res)
    logouttbtn.config(command=d)
    root.mainloop()

def result():
    root = Toplevel()
    root.title("Autism Detection System-Result")
    root.resizable(False, False)
    root.geometry("650x500")
    root.configure(background='#ffffff')

    img = ImageTk.PhotoImage(Image.open("icon2.png"))
    panel = Label(root, image=img)
    panel.pack(pady=20)

    tv = ttk.Treeview(root)
    tv.pack(pady=5)
    tv.heading("#0", text="ID")
    tv.configure(column=('Name', 'Result'))
    tv.heading("Name", text="Child Name")
    tv.heading("Result", text="Result")

    homebtn = Button(root, text="Home", bg='#AFAF1D', fg='#ffffff', font="Bold 12", relief='flat',
                       borderwidth=3)
    homebtn.pack()

    def h():
        root.destroy()
        g=home()

    homebtn.config(command=h)
    root.mainloop()
def onFrameConfigure(canvas):
    '''Reset the scroll region to encompass the inner frame'''
    canvas.configure(scrollregion=canvas.bbox("all"))

def exam():
    root = Toplevel()
    root.title("Autism Detection System-Exam")
    root.resizable(False, False)
    root.geometry("590x490")
    root.configure(background='#ffffff')
    canvas = Canvas(root, borderwidth=0)
    frame = ttk.Frame(canvas, style='My.TFrame')
    vsb = ttk.Scrollbar(root, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=vsb.set)
    vsb.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    canvas.create_window((4, 4), window=frame, anchor="nw")
    frame.bind("<Configure>", lambda event, canvas=canvas: onFrameConfigure(canvas))

    lbl1 = ttk.Label(frame, text="Answer the following questions:", background='#ffffff', font="Bold 15",
                         foreground="#AFAF1D")
    lbl1.pack( pady=10,padx=10)
    namelbl = ttk.Label(frame, text="Enter child's name:", background='#ffffff', font="Bold 10",
                       foreground="#AFAF1D")
    namelbl.pack(pady=5)
    nametxt = ttk.Entry(frame, font=('Arial', 10))
    nametxt.pack(pady=5)
    agelbl=ttk.Label(frame, text="Enter child's age:", background='#ffffff', font="Bold 10",
                         foreground="#AFAF1D")
    agelbl.pack(pady=5)
    agetxt=ttk.Entry(frame, font=('Arial',10))
    agetxt.pack(pady=5)

    style = ttk.Style()
    style.configure("TRadiobutton", background="#ffffff", foreground="#737373")
    style.configure('My.TFrame', background='#ffffff')

    q1lbl = ttk.Label(frame, text="Does the person avoid meeting eyes?", background='#ffffff', font="Bold 10",
                       foreground="#AFAF1D")
    q1lbl.pack(pady=5)
    Spanq1 = StringVar()
    q1yes=ttk.Radiobutton(frame, text="Yes", variable=Spanq1, value="Yes")
    q1no = ttk.Radiobutton(frame, text="No", variable=Spanq1, value="No")
    q1yes.pack(pady=5)
    q1no.pack(pady=5)

    q2lbl = ttk.Label(frame, text="Does the person vibrates forward and backward while standing and sitting?", background='#ffffff', font="Bold 10",
                      foreground="#AFAF1D")
    q2lbl.pack(pady=5)
    Spanq2 = StringVar()
    q2yes = ttk.Radiobutton(frame, text="Yes", variable=Spanq2, value="Yes")
    q2no = ttk.Radiobutton(frame, text="No", variable=Spanq2, value="No")
    q2yes.pack(pady=5)
    q2no.pack(pady=5)

    q3lbl = ttk.Label(frame, text="Is the person's response inappropriate for simple orders?",
                      background='#ffffff', font="Bold 10",
                      foreground="#AFAF1D")
    q3lbl.pack(pady=5)
    Spanq3 = StringVar()
    q3yes = ttk.Radiobutton(frame, text="Yes", variable=Spanq3, value="Yes")
    q3no = ttk.Radiobutton(frame, text="No", variable=Spanq3, value="No")
    q3yes.pack(pady=5)
    q3no.pack(pady=5)

    q4lbl = ttk.Label(frame, text="Is the person's response inappropriate for simple orders?",
                      background='#ffffff', font="Bold 10",
                      foreground="#AFAF1D")
    q4lbl.pack(pady=5)
    Spanq4 = StringVar()
    q4yes = ttk.Radiobutton(frame, text="Yes", variable=Spanq4, value="Yes")
    q4no = ttk.Radiobutton(frame, text="No", variable=Spanq4, value="No")
    q4yes.pack(pady=5)
    q4no.pack(pady=5)

    q5lbl = ttk.Label(frame, text="Does the person realize the presence of people around him/her?",
                      background='#ffffff', font="Bold 10",
                      foreground="#AFAF1D")
    q5lbl.pack(pady=5)
    Spanq5 = StringVar()
    q5yes = ttk.Radiobutton(frame, text="Yes", variable=Spanq5, value="Yes")
    q5no = ttk.Radiobutton(frame, text="No", variable=Spanq5, value="No")
    q5yes.pack(pady=5)
    q5no.pack(pady=5)

    q6lbl = ttk.Label(frame, text="Does the person look at the vast space a lot?",
                      background='#ffffff', font="Bold 10",
                      foreground="#AFAF1D")
    q6lbl.pack(pady=5)
    Spanq6 = StringVar()
    q6yes = ttk.Radiobutton(frame, text="Yes", variable=Spanq6, value="Yes")
    q6no = ttk.Radiobutton(frame, text="No", variable=Spanq6, value="No")
    q6yes.pack(pady=5)
    q6no.pack(pady=5)

    q7lbl = ttk.Label(frame, text="Does the person seem deaf to some voices while responding to other voices?",
                      background='#ffffff', font="Bold 10",
                      foreground="#AFAF1D")
    q7lbl.pack(pady=5)
    Spanq7 = StringVar()
    q7yes = ttk.Radiobutton(frame, text="Yes", variable=Spanq7, value="Yes")
    q7no = ttk.Radiobutton(frame, text="No", variable=Spanq7, value="No")
    q7yes.pack(pady=5)
    q7no.pack(pady=5)

    q8lbl = ttk.Label(frame, text="Does the person use inappropriate pronouns?",
                      background='#ffffff', font="Bold 10",
                      foreground="#AFAF1D")
    q8lbl.pack(pady=5)
    Spanq8 = StringVar()
    q8yes = ttk.Radiobutton(frame, text="Yes", variable=Spanq8, value="Yes")
    q8no = ttk.Radiobutton(frame, text="No", variable=Spanq8, value="No")
    q8yes.pack(pady=5)
    q8no.pack(pady=5)

    q9lbl = ttk.Label(frame, text="Does the person do things repeatedly as if they were rituals?",
                      background='#ffffff', font="Bold 10",
                      foreground="#AFAF1D")
    q9lbl.pack(pady=5)
    Spanq9 = StringVar()
    q9yes = ttk.Radiobutton(frame, text="Yes", variable=Spanq9, value="Yes")
    q9no = ttk.Radiobutton(frame, text="No", variable=Spanq9, value="No")
    q9yes.pack(pady=5)
    q9no.pack(pady=5)

    q10lbl = ttk.Label(frame, text="Is the person unemotional or unfriendly,  does not give an emotional response to hugs or kisses?",
                      background='#ffffff', font="Bold 10",
                      foreground="#AFAF1D")
    q10lbl.pack(pady=5)
    Spanq10 = StringVar()
    q10yes = ttk.Radiobutton(frame, text="Yes", variable=Spanq10, value="Yes")
    q10no = ttk.Radiobutton(frame, text="No", variable=Spanq10, value="No")
    q10yes.pack(pady=5)
    q10no.pack(pady=5)

    q11lbl = ttk.Label(frame, text="Does the person make constant gestures and signals?",
                       background='#ffffff', font="Bold 10",
                       foreground="#AFAF1D")
    q11lbl.pack(pady=5)
    Spanq11 = StringVar()
    q11yes = ttk.Radiobutton(frame, text="Yes", variable=Spanq11, value="Yes")
    q11no = ttk.Radiobutton(frame, text="No", variable=Spanq11, value="No")
    q11yes.pack(pady=5)
    q11no.pack(pady=5)

    resultbtn = Button(frame, text="Check the Results", bg='#AFAF1D', fg='#ffffff', font="Bold 10", relief='flat',
                       borderwidth=3)
    resultbtn.pack(pady=10)

    def res():
        root.withdraw()
        r=result()

    resultbtn.config(command=res)
    root.mainloop()