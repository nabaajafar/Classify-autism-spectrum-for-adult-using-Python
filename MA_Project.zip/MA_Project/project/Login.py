from tkinter import *
from tkinter import ttk
from PIL import ImageTk, Image
from Register import r
from homepage import home

root=Tk()
root.title("Autism Detection System-Sign In")
root.resizable(False,False)
root.geometry("500x490")
root.configure(background='#ffffff')

lbl1= ttk.Label(root,text="Autism Detection System", background='#ffffff', font="Bold 25", foreground="#AFAF1D" )
lbl1.pack(padx=20, pady=20)

usernamelbl=ttk.Label(root,text="Username:", background='#ffffff', font="Bold 15", foreground="#AFAF1D")
usernamelbl.pack(padx=(10,125),pady=5)
usernametext=ttk.Entry(root, width=30, font=('Arial',10))
usernametext.pack(pady=5)

passlbl=ttk.Label(root,text="Password:", background='#ffffff', font="Bold 15", foreground="#AFAF1D")
passlbl.pack(padx=(10,125),pady=5)
passtext=ttk.Entry(root, width=30, font=('Arial',10))
passtext.config(show="*")
passtext.pack(pady=5)

loginbtn=Button(root, text="Sign In", bg='#AFAF1D', fg='#ffffff', font="Bold 10",  relief='flat', borderwidth=5)
loginbtn.pack(pady=5)

regbtn=Button(root, text="Sign Up", bg='#AFAF1D', fg='#ffffff', font="Bold 10",  relief='flat', borderwidth=3)
regbtn.pack(pady=5)
img = ImageTk.PhotoImage(Image.open("icon.png"))
panel = Label(root, image = img)
panel.pack()

def signup():
    sign=r()

def homepage():
    root.withdraw()
    go = home()

regbtn.config(command=signup)
loginbtn.config(command=homepage)
root.mainloop()

